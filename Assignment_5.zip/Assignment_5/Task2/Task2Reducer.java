import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

/*
Extends the default Reducer class with arguments KeyIn as Text and ValueIn as IntWritable 
which are same as the outputs of the mapper class and KeyOut as Text and ValueOut as IntWritbale 
which will be final outputs of our MapReduce program.
*/

public class Task2Reducer extends Reducer<NullWritable,IntWritable, Text, NullWritable>
{	
	//Overriding the Reduce method which will run each time for every key.
	@Override
	public void reduce(NullWritable key, Iterable<IntWritable> values,Context context) throws IOException, InterruptedException
	{	
		// Declaration & initialization of an integer variable 
		int sum=0;
		//Iterating through values received from Map output
		 for (IntWritable value : values) {
			 
			//Adding the count of values to get the total.
			sum+=value.get();	
		       }
		 //Testing value of sum	
		 System.out.println("Sum val"+sum);
		 
		 //Storing the value within a string to be displayed within output file.
		 String heard = "Number of times a song was heard fully is : "+sum;

		 //Writing Number of times a song was heard fully within final output FILE.
	     context.write(new Text(heard),NullWritable.get());
	}
}