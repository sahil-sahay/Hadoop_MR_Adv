import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.*;

/*
Taking a class by the name Task2Mapper.
Extending the Mapper default class having the arguments keyIn as 
LongWritable, ValueIn as Text, KeyOut as IntWritable and ValueOut as NullWritable(Since only distinct id's are required).
*/

public class Task2Mapper extends Mapper<LongWritable, Text, NullWritable,IntWritable> {
	
	/*
	IntWritable variable �userId� which will be contain different user id's from input dataset.
	MapReduce deals with Key and Value pairs.
	 */
	IntWritable userId=new IntWritable();
	int heardFully;
		
	//Overriding the map method which will run one time for every line.
	@Override
	public void map(LongWritable key, Text value, Context context) 
			throws IOException, InterruptedException {
		
		/*
		Converting values to string & storing the line in a string variable �lineArray�.
		Splitting the line by using pipe �|� delimiter. Since pipe is a metacharacter, need to suppress using backslash
		to treat it as a normal pipe character & hide it's special meaning.
		and storing the values in a String Array lineArray, so that all the columns in a row are stored in the string array.
		 */
		String[] lineArray = value.toString().split("\\|");
		
		//Fetching Song Listening Status (0 for skipped, 1 for fully heard)
		heardFully=Integer.parseInt(lineArray[4]);
		
		//Checking value fetched
		System.out.println("Heard Fully"+heardFully);
		/*
		The mapper will emit each userId as the key, and null as the value. 
		The reducer will take the key and a collection of associated output values from the mapper. 
		Since we will only have one reduce task per key, emitting each key and no values will output the distinct values.
		*/
		//Filtering only those columns that have 1(Song Listening Status (0 for skipped, 1 for fully heard))
		if(heardFully == 1) {
			
		//Sending the count of fully heard to Reduce input for aggregation
		context.write(NullWritable.get(),new IntWritable(heardFully));
		}
	}
}