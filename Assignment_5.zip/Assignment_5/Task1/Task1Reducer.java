import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Reducer;

/*
Extends the default Reducer class with arguments KeyIn as Text and ValueIn as IntWritable 
which are same as the outputs of the mapper class and KeyOut as Text and ValueOut as IntWritbale 
which will be final outputs of our MapReduce program.
*/

public class Task1Reducer extends Reducer<IntWritable, NullWritable, IntWritable, NullWritable>
{	
	//Overriding the Reduce method which will run each time for every key.
	@Override
	public void reduce(IntWritable key, Iterable<NullWritable> values,Context context) throws IOException, InterruptedException
	{		
		  //Writing distinct keys to produce final output.
	      context.write(key,NullWritable.get());
	}
}