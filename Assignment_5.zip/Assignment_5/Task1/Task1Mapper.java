import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.*;

/*
Taking a class by the name Task1Mapper.
Extending the Mapper default class having the arguments keyIn as 
LongWritable, ValueIn as Text, KeyOut as IntWritable and ValueOut as NullWritable(Since only distinct id's are required).
*/

public class Task1Mapper extends Mapper<LongWritable, Text, IntWritable,NullWritable> {
	
	/*
	IntWritable variable �userId� which will be contain different user id's from input dataset.
	MapReduce deals with Key and Value pairs.
	 */
	IntWritable userId=new IntWritable();
		
	//Overriding the map method which will run one time for every line.
	@Override
	public void map(LongWritable key, Text value, Context context) 
			throws IOException, InterruptedException {
		
		/*
		Converting values to string & storing the line in a string variable �lineArray�.
		Splitting the line by using pipe �|� delimiter. Since pipe is a metacharacter, need to suppress using backslash
		to treat it as a normal pipe character & hide it's special meaning.
		and storing the values in a String Array lineArray, so that all the columns in a row are stored in the string array.
		 */
		String[] lineArray = value.toString().split("\\|");
		
		
		/*
		 * Checking value getting stored in lineArray
		//for(String word:lineArray) {
		//System.out.println("Word in for  =>"+word);
		//}
		 * */
		
		//Storing user id in the declared variable "userId"
		userId.set(Integer.parseInt(lineArray[0]));

		//System.out.println("Value =>"+value);
		//System.out.println("lineArray length=>"+lineArray.length);
		//System.out.println("User Id =>"+userId);
		
		/*
		The mapper will emit each userId as the key, and null as the value. 
		The reducer will take the key and a collection of associated output values from the mapper. 
		Since we will only have one reduce task per key, emitting each key and no values will output the distinct values.
		*/
		
		context.write(userId,NullWritable.get());
	}
}