import org.apache.hadoop.fs.Path; 
import org.apache.hadoop.conf.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat; 
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat; 
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat; 
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;

//Main class of Driver Code
public class Task3Driver {
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws Exception {
		
		if (args.length != 2) {
			//Illustration of how to run this code
		      System.err.println("Usage: hadoop jar <jar file name/path> <input path> <output path>");
		      System.exit(-1);
		    }
		
		//Job Related Configurations
		Configuration conf = new Configuration();
		Job job = new Job(conf, "Task3");
		job.setJarByClass(Task3Driver.class);

		//setting up the Map output key and output value classes 
		job.setMapOutputKeyClass(NullWritable.class);
		job.setMapOutputValueClass(IntWritable.class);

		//Feeding mapper class to job
		job.setMapperClass(Task3Mapper.class);

		//Feeding Reducer class to job
		job.setReducerClass(Task3Reducer.class);
		
		//Setting number of Reducer task to 1
		job.setNumReduceTasks(1);
		 
		//Setting the Input and Output format class
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		//Providing path to pick the input file for the job
		FileInputFormat.addInputPath(job, new Path(args[0])); 
		//Providing path to dump the output for the job
		Path outputPath = new Path(args[1]);
		FileOutputFormat.setOutputPath(job, outputPath);
		
		//Delete the output file,if already present
		outputPath.getFileSystem(conf).delete(outputPath, true);
		
	    //Execute the job by checking condition using a ternary operator for success or failure of job
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
